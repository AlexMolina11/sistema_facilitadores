@php
    $steps = [
        1 => ['label' => 'Perfil Personal', 'route' => isset($consultor) ? route('fac.consultores.edit', $consultor) : null],
        2 => ['label' => 'Contacto', 'route' => isset($consultor) ? route('fac.consultores.contacto.edit', $consultor) : null],
        3 => ['label' => 'Experiencia', 'route' => isset($consultor) ? route('fac.consultores.experiencia.edit', $consultor) : null],
        4 => ['label' => 'Títulos Académicos', 'route' => isset($consultor) ? route('fac.consultores.formacion.edit', $consultor) : null],
        5 => ['label' => 'Habilidades', 'route' => isset($consultor) ? route('fac.consultores.habilidades.edit', $consultor) : null],
        6 => ['label' => 'Idiomas', 'route' => isset($consultor) ? route('fac.consultores.idiomas.edit', $consultor) : null],
        7 => ['label' => 'Referencias', 'route' => isset($consultor) ? route('fac.consultores.referencias.edit', $consultor) : null],
        8 => ['label' => 'Disponibilidad', 'route' => isset($consultor) ? route('fac.consultores.disponibilidad.edit', $consultor) : null],
        9 => ['label' => 'Seguimiento', 'route' => isset($consultor) ? route('fac.consultores.seguimiento.edit', $consultor) : null],
    ];
@endphp

<div class="perfil-tabs mb-4">
    @foreach($steps as $number => $item)
        @if($item['route'])
            <a href="{{ $item['route'] }}" class="perfil-tab {{ (int) $step === (int) $number ? 'active' : '' }}">
                {{ $item['label'] }}
            </a>
        @else
            <span class="perfil-tab {{ (int) $step === (int) $number ? 'active' : '' }}">
                {{ $item['label'] }}
            </span>
        @endif
    @endforeach
</div>

@push('styles')
<style>
    .perfil-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: .5rem;
        border-bottom: 1px solid #e5e7eb;
        padding-bottom: .5rem;
    }

    .perfil-tab {
        display: inline-flex;
        align-items: center;
        min-height: 38px;
        padding: .6rem 1rem;
        border-radius: .5rem .5rem 0 0;
        background: #f3f4f6;
        color: #1f2937;
        text-decoration: none;
        font-weight: 600;
        font-size: .92rem;
        border: 1px solid transparent;
        border-bottom: 0;
    }

    .perfil-tab:hover {
        color: #a6192e;
        background: #fff;
    }

    .perfil-tab.active {
        background: #fff;
        color: #a6192e;
        border-color: #a6192e;
    }
</style>
@endpush
